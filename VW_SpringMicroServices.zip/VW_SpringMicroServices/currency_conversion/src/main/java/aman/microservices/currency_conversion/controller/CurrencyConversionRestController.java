package aman.microservices.currency_conversion.controller;

import java.math.BigDecimal;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import aman.microservices.currency_conversion.model.CurrencyConversion;

@RestController
public class CurrencyConversionRestController {

    @Autowired
    private RestTemplate restTemplate;
    
    @Autowired
	private CurrencyExchangeProxy proxy;
    
    Logger logger = LoggerFactory.getLogger(CurrencyConversionRestController.class);

    @GetMapping("/convert/from/{from}/to/{to}/quantity/{quantity}")
    public CurrencyConversion calculateCurrencyConversion(
            @PathVariable String from,
            @PathVariable String to,
            @PathVariable BigDecimal quantity) {

        // Creating a map for path variables
        HashMap<String, String> pathVariable = new HashMap<>();
        pathVariable.put("from", from);
        pathVariable.put("to", to);

        // URL with dynamic path variables
        String url = "http://localhost:8001/exchangerate/from/{from}/to/{to}";

        // Making a GET request
        ResponseEntity<CurrencyConversion> responseEntity = restTemplate.getForEntity(url, CurrencyConversion.class, pathVariable);

        CurrencyConversion currencyConversion = responseEntity.getBody();

        // Calculating final amount
        BigDecimal finalAmount = quantity.multiply(currencyConversion.getConversionRate());

        currencyConversion.setCalculateAmt(finalAmount);
        currencyConversion.setQuantity(quantity);

        return currencyConversion;
    }
    
    
    @GetMapping("/currency-conversion-feign/from/{from}/to/{to}/quantity/{quantity}")
	public CurrencyConversion calculateCurrencyConversionFeign(
			@PathVariable String from,
			@PathVariable String to,
			@PathVariable BigDecimal quantity
			) {
    	
    	logger.info("currencyconversionfeign:from:"+from+",to:"+to+",quantity:"+quantity);
				
		CurrencyConversion currencyConversion = proxy.retrieveExchangeValue(from, to);
		
		logger.info("currencyconversionfeign:"+currencyConversion);
		
		currencyConversion.setQuantity(quantity);
		
		BigDecimal conversionMultiple = currencyConversion.getConversionRate();
		BigDecimal totalCalculateAmount = quantity.multiply(conversionMultiple);

		
		currencyConversion.setCalculateAmt(totalCalculateAmount);
		logger.info("after setting calculated amt, currencyConversionfeign:"+currencyConversion);
		
		return currencyConversion;
	}
}
