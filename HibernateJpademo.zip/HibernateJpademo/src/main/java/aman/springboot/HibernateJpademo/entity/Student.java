package aman.springboot.HibernateJpademo.entity;

import jakarta.persistence.*;


@Entity
@Table(name="stud")
public class Student {

   @Id
   @GeneratedValue
   int StudId;


@Column(name="studname")
    String name;

   int totalMarks;

    @OneToOne// default value for fetch type is EAGER
    @JoinColumn(name="p_id")
    Passport passemp;


    protected Student() {

    }

    public Student(String name, int totalMarks, Passport passemp) {
        this.name = name;
        this.totalMarks = totalMarks;
        this.passemp = passemp;
    }


    public long getStudId() {
        return StudId;
    }

    public void setStudId(int studId) {
        StudId = studId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getTotalMarks() {
        return totalMarks;
    }

    public void setTotalMarks(int totalMarks) {
        this.totalMarks = totalMarks;
    }

    public Passport getPassemp() {
        return passemp;
    }

    public void setPassemp(Passport passemp) {
        this.passemp = passemp;
    }


    @Override
    public String toString() {
        return "Student{" +
                "StudId=" + StudId +
                ", name='" + name + '\'' +
                ", totalMarks=" + totalMarks +
                ", passemp=" + passemp +
                '}';
    }
}
