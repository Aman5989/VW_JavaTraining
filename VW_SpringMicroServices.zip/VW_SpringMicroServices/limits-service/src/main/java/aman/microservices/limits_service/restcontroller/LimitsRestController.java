package aman.microservices.limits_service.restcontroller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import aman.microservices.limits_service.model.Limits;

@RestController
public class LimitsRestController {
	
	@Value("${limits-service.minimum}")
	private int minimum;
	
	@Value("${limits-service.maximum}")
	private int maximum;
	
	
	
	@GetMapping("/limits")
	public Limits getLimits( ) {
		return new Limits(this.minimum,this.maximum);
	}

}
