package aman.springboot.HibernateJpademo.jparepo;

import aman.springboot.HibernateJpademo.entity.Passport;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PassportSpringDataJpaRepository extends JpaRepository<Passport, Long> {
}
