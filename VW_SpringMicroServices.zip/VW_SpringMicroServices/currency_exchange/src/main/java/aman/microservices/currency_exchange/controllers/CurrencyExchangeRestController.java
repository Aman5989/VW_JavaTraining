package aman.microservices.currency_exchange.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import aman.microservices.currency_exchange.entity.CurrencyExchange;
import aman.microservices.currency_exchange.repository.CurrencyExchangeJpa;

@RestController
public class CurrencyExchangeRestController {
	
	@Autowired
	CurrencyExchangeJpa repo;
	
	@Autowired
	Environment env;
	
	
	
	
	@GetMapping("exchangerate/from/{from}/to/{to}")
	public CurrencyExchange getExchangeRate(@PathVariable String to, @PathVariable String from) {
		
		
		CurrencyExchange ce = this.repo.findByFromAndTo(from, to);
		String env = this.env.getProperty("local.server.port");
		ce.setEnvironment(env);
		return ce;
		
	}

}
