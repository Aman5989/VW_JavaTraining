package aman.springboot.HibernateJpademo.restcontrollers;


import aman.springboot.HibernateJpademo.entity.Passport;
import aman.springboot.HibernateJpademo.entity.Student;
import aman.springboot.HibernateJpademo.jparepo.PassportSpringDataJpaRepository;
import aman.springboot.HibernateJpademo.jparepo.StudentJpaRepo;
import aman.springboot.HibernateJpademo.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@RestController
public class StudentRestController {


    @Autowired
    StudentService studentService;



    public  StudentRestController()
    {


    }

    @GetMapping("/stud/{StudId}")
    public ResponseEntity<Student> getStudent(@PathVariable int StudId) {
       Student s = studentService.getStudentById(StudId);
        if (s!=null) {
            return new ResponseEntity<>(s, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        }
    }




    @GetMapping("/all/stud")
    public ResponseEntity <List<Student>> getAllStudents()
    {
        return new ResponseEntity<>(studentService.getAllStudents(), HttpStatus.OK);
    }




//    @PostMapping("/student")
//    public ResponseEntity<Student> addStudent(@RequestBody Student s) {
//        if (s == null) {
//            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
//        } else {
//            Student s1 = srepo.save(s);
//            return new ResponseEntity<>(s1, HttpStatus.OK);
//        }
//    }



//    @GetMapping("/stud/passport/{id}")
//    public ResponseEntity<Passport> getStudentPassport(@PathVariable int id) {
//        Optional<Student> student = srepo.findById(id);
//        if (student.isPresent()) {
//            return new ResponseEntity<>(student.get().getPassemp(), HttpStatus.OK);
//        } else {
//            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
//        }
//    }


    @PostMapping("/passport")
    public ResponseEntity<Passport> addPassport(@RequestBody Passport p) {
        if (p == null) {
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        } else {
            Passport p1 = studentService.addPassport(p);
            return new ResponseEntity<>(p1, HttpStatus.CREATED);
        }
    }


//    @GetMapping("/stude/name/{name}")
//    public ResponseEntity<Student> getStudentByName(@PathVariable String name) {
//        Optional<Student> student = srepo.findByName(name);
//        if (student.isPresent()) {
//            return new ResponseEntity<>(student.get(), HttpStatus.OK);
//        } else {
//            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
//        }
//    }




}
