package aman.microservices.currency_conversion.controller;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import aman.microservices.currency_conversion.model.CurrencyConversion;


//@FeignClient(name="currency-exchange", url="localhost:8000")
@FeignClient(name="currency-exchange")
public interface CurrencyExchangeProxy {
	
	@GetMapping("/exchangerate/from/{from}/to/{to}")
	CurrencyConversion retrieveExchangeValue(
			@PathVariable String from,
			@PathVariable String to);

}
