package aman.springboot.HibernateJpademo.jparepo;

import aman.springboot.HibernateJpademo.entity.Student;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.awt.print.Pageable;
import java.util.List;
import java.util.Optional;

@Repository
public interface StudentJpaRepo extends JpaRepository<Student, Integer> {
    void deleteByName(String name);


    Long countByName(String name);

   Optional<Student> findByName(String name);

//   List<Student> findAllByTotalMarks(int totalMarks, Pageable pageable);


 @Query("Select s from Student s where s.name like '%a%'")
 List<Student> studentWithPatternInName();


 @Query(value = "select * from stud where studname like '%m%'", nativeQuery = true)
 List<Student> studentWithPatternInNameUsingNativeQuery();


}
