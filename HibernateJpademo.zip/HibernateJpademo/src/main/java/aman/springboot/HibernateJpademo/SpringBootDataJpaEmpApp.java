package aman.springboot.HibernateJpademo;

import aman.springboot.HibernateJpademo.entity.Employee;
import aman.springboot.HibernateJpademo.entity.Passport;
import aman.springboot.HibernateJpademo.jparepo.EmployeeSpringDataJpaRepository;
import aman.springboot.HibernateJpademo.jparepo.PassportSpringDataJpaRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import java.time.LocalDate;
import java.util.Optional;

@SpringBootApplication
public class SpringBootDataJpaEmpApp implements CommandLineRunner {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private EmployeeSpringDataJpaRepository repo;


	@Autowired
	private PassportSpringDataJpaRepository passportRepo;

	public static void main(String[] args) {

		SpringApplication.run(SpringBootDataJpaEmpApp.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

//		Employee e = new Employee("Aman",9000);
//		repo.save(e);
//
//		Employee e1 = new Employee("Ayush",3000);
//		repo.save(e1);
//
//		Employee e2 = new Employee("Anmol",7000);
//		repo.save(e2);
//
//		Employee e3 = new Employee("Aryan",2000);
//		repo.save(e3);
//
//		System.out.println(repo.findById(3L));
//		logger.info("Employee total count -> {}", repo.count());
//
//		repo.deleteById(3L);
//		logger.info("Employee total count -> {}", repo.count());


		Passport p1 = new Passport("Aman", LocalDate.now());
		passportRepo.save(p1);
		Passport p2 = new Passport("Anmol", LocalDate.now());
		passportRepo.save(p2);
		Passport p3 = new Passport("Ayush", LocalDate.now());
		passportRepo.save(p3);


		Employee e4 = new Employee("Aman",4000,p1);
		repo.save(e4);

		Employee e5 = new Employee("Anmol",9000,p2);
		repo.save(e5);

		Employee e6 = new Employee("Ayush",3000,p3);
		repo.save(e6);

		System.out.println(repo.findById(1L));

		getEmpbyId(1L);
		getEmpbyName("Aman");
		repo.deleteById(1L);
		System.out.println(repo.count());
		logger.info("Employee total count -> {}", repo.count());

	}





	public void getEmpbyId(long id)
	{
		Optional<Employee> x = repo.findById(id);
		if (x.isPresent()) {
			Employee e = x.get();
			Passport p = e.getPassemp();
			System.out.println(p);

		}
	}


	public void getEmpbyName(String name)
	{
		Optional<Employee> x = repo.findByName(name);
		if (x.isPresent())
		{
			System.out.println(x.get());
		}
	}


	public void deleteEmpbyId(long id)
	{
		repo.deleteById(id);
	}


	public void count()
	{
		repo.count();
	}


}
