package aman.springboot.HibernateJpademo.entity;

import jakarta.persistence.*;


@Entity
@Table(name="Emp")
public class Employee {

   @Id
   @GeneratedValue
   long empId;



    String name;


     double salary;

    @OneToOne(fetch=FetchType.LAZY) // default value for fetch type is EAGER
    @JoinColumn(name="p_id")
    Passport passemp;


    protected Employee() {

    }

    public Employee(String name, double salary, Passport passemp) {
        this.name = name;
        this.salary = salary;
        this.passemp = passemp;
    }



    public long getEmpId() {
        return empId;
    }

    public void setEmpId(long empId) {
        this.empId = empId;
    }

    public String getname() {
        return name;
    }

    public void setname(String name) {
        this.name = name;
    }

    public double getEmpSal() {
        return salary;
    }

    public void setEmpSal(double empSal) {
        this.salary = salary;
    }

    public Passport getPassemp() {
        return passemp;
    }

    public void setPassemp(Passport passemp) {
        this.passemp = passemp;
    }


    @Override
    public String toString() {
        return "Employee{" +
                "empId=" + empId +
                ", empName='" + name + '\'' +
                ", empSal=" + salary +
                ", passemp=" + passemp +
                '}';
    }
}
