package aman.springboot.HibernateJpademo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDataJpaEmpAppTests {

	@Test
	void contextLoads() {
	}

}
