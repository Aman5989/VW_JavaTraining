package aman.springboot.HibernateJpademo.jparepo;

import aman.springboot.HibernateJpademo.entity.Employee;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Transactional
@Repository
public interface EmployeeSpringDataJpaRepository extends JpaRepository<Employee, Long> {

    @EntityGraph(attributePaths = "passemp")
    Optional<Employee> findById(Long id);

    @EntityGraph(attributePaths = "passemp")
    Optional<Employee> findByName(String name);

    @EntityGraph(attributePaths = "passemp")
    Optional<Employee> findByNameAndSalary(String name, double salary);




}
