package aman.springboot.HibernateJpademo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import java.time.LocalDate;

@Entity
public class Passport {

    @Id
    @GeneratedValue
     long passportId;

     String name;
     LocalDate issueDate;

    protected Passport() {
    }

    public Passport(String name, LocalDate issueDate) {
        this.name = name;
        this.issueDate = issueDate;
    }

    public long getPassportId() {
        return passportId;
    }

    public void setPassportId(long passportId) {
        this.passportId = passportId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDate getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(LocalDate issueDate) {
        this.issueDate = issueDate;
    }


    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Passport passport = (Passport) o;
        return passportId == passport.passportId;
    }

    @Override
    public int hashCode() {
        return 0;
    }

    @Override
    public String toString() {
        return "Passport{" +
                "passportId=" + passportId +
                ", name='" + name + '\'' +
                ", issueDate=" + issueDate +
                '}';
    }
}
