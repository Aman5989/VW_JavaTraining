package aman.springboot.HibernateJpademo.service;

import aman.springboot.HibernateJpademo.entity.Passport;
import aman.springboot.HibernateJpademo.entity.Student;
import aman.springboot.HibernateJpademo.jparepo.PassportSpringDataJpaRepository;
import aman.springboot.HibernateJpademo.jparepo.StudentJpaRepo;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StudentService {

    @Autowired
    private StudentJpaRepo srepo;

    @Autowired
    private PassportSpringDataJpaRepository passrepo;


    public List<Student> getAllStudents() {
        return srepo.findAll();
    }

    public Student getStudentById(int id) {
        Optional<Student> student = srepo.findById(id);
        if (student.isPresent()) {
            return student.get();
        }else {
            return null;
        }
    }

    @Transactional
    public Passport addPassport(Passport p)
    {
       Passport p1 = passrepo.save(p);
                     passrepo.flush();
                     return p1;
    }
}
