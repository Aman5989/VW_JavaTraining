package aman.springboot.HibernateJpademo;

import aman.springboot.HibernateJpademo.entity.Employee;
import aman.springboot.HibernateJpademo.entity.Passport;
import aman.springboot.HibernateJpademo.entity.Student;
import aman.springboot.HibernateJpademo.jparepo.EmployeeSpringDataJpaRepository;
import aman.springboot.HibernateJpademo.jparepo.PassportSpringDataJpaRepository;
import aman.springboot.HibernateJpademo.jparepo.StudentJpaRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.time.LocalDate;
import java.util.Optional;

@SpringBootApplication
public class SpringBootDataJpaStudApp implements CommandLineRunner {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private EmployeeSpringDataJpaRepository repo;


	@Autowired
	private PassportSpringDataJpaRepository passportRepo;

	@Autowired
	private StudentJpaRepo srepo;

	public static void main(String[] args) {

		SpringApplication.run(SpringBootDataJpaStudApp.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		Passport p1 = new Passport("Aman", LocalDate.now());
		passportRepo.save(p1);
		Passport p2 = new Passport("Ayush", LocalDate.now());
		passportRepo.save(p2);
		Passport p3 = new Passport("Aryan", LocalDate.now());
		passportRepo.save(p3);
		Passport p4 = new Passport("Prince", LocalDate.now());
		passportRepo.save(p4);
		Passport p5 = new Passport("Rohit", LocalDate.now());
		passportRepo.save(p5);


		Student s1 = new Student("Aman",90,p1);
		srepo.save(s1);
		Student s2 = new Student("Ayush",50,p2);
		srepo.save(s2);
		Student s3 = new Student("Aryan",90,p3);
		srepo.save(s3);
		Student s4 = new Student("Prince",50,p4);
		srepo.save(s4);
		Student s5 = new Student("Rohit",50,p5);
		srepo.save(s5);


		long ct = srepo.count();







//pagination
		for (int i=0;i<ct/2;i++) {
			System.out.println("Batch"+(i+1));
			Pageable firstPageWithTwoElements = PageRequest.of(i, 2);
			Page<Student> p = srepo.findAll(firstPageWithTwoElements);
			p.get().forEach(System.out::println);
		}

	}






}
